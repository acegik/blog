use tempdb;

create table A (
	A1 int identity(1,1) primary key,
	A2 int
);
GO

create table B (
	B1 int  identity(1,1) primary key,
	B2 int,
	A_B int	
);
GO


insert into A values (1);
insert into A values (2);
insert into A values (3);
insert into A values (4);
select * from A;
Go

insert into B(B2, A_B) values (1, 1);
insert into B(B2, A_B) values (2, 1);
insert into B(B2, A_B) values (3, 2);
insert into B(B2) values (4);
select * from B;
GO

select A2, A1, A_B, B1, B2 from A, B where A_B = A1;

select A2, A1, A_B, B1, B2 from A INNER JOIN B ON A_B = A1;

select A2, A1, A_B, B1, B2 from A left outer join B on B.A_B = A.A1;

select A2, A1, A_B, B1, B2 from A right outer join B on B.A_B = A.A1;

select A2, A1, A_B, B1, B2 from A full outer join B on B.A_B = A.A1;

