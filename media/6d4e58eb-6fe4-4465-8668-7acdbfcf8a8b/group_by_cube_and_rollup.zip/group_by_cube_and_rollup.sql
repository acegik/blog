-- Su dung co so du lieu tempdb cho vi du nay
Use tempdb;

Select OrderID, Sum(Quantity) From [Order Details] Group By OrderID WITH ROLLUP;

Select OrderID, Sum(Quantity) From [Order Details] Group By OrderID WITH CUBE;

Select Sum(Quantity) From [Order Details];

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Tao co so du lieu Student, them du lieu 
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
create table Student ( [name] nchar(30), [subject] nchar(10), [mark] float); 

insert into Student values('Hung', 'JAVA', 8);
insert into Student values('Hung', 'C', 9);
insert into Student values('Hung', 'C', 7);
insert into Student values('Hung', 'SQL', 5);
insert into Student values('Tuan', 'JAVA', 4);
insert into Student values('Tuan', 'C', 7);
insert into Student values('Tuan', 'SQL', 10);
insert into Student values('Tuan', 'SQL', 5);

SELECT [name] AS [Student name], [subject] AS [Subject name], [mark] AS [Mark] FROM Student;

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Tinh diem trung binh cua tung sinh vien bang cach su dung GROUP BY va AVG
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
SELECT [name] as [Student name], [subject] as [Subject name], AVG([mark]) AS [Average mark] 
	FROM Student GROUP BY [name], [subject];

-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-- Tinh diem trung binh cua tung sinh vien, diem trung binh tat ca cac mon 
-- cua tung sinh vien bang cach su dung ham AVG va GROUP BY ... WITH ROLLUP
-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
SELECT [name] as [Student name], [subject] as [Subject name], AVG([mark]) 
	FROM Student GROUP BY [name], [subject] WITH ROLLUP;

-- Giong lenh tren, nhung ta lam tron diem trung binh
SELECT 
	[name] as [Student name], 
	[subject] as [Subject name], 
	CAST(AVG([mark]) AS DECIMAL(9, 2)) AS [Average mark] 
	FROM Student GROUP BY [name], [subject] WITH ROLLUP;

-- Giong lenh tren, doi NULL thanh 'All students' va 'All subjects'
SELECT 
	CASE when GROUPING([name]) = 1 THEN 'All students' ELSE [name] END
		AS [Student name],
	CASE when GROUPING([subject]) = 1 THEN 'All subjects' ELSE [subject] END
		AS [Subject name], 
	CAST(AVG([mark]) AS DECIMAL(9, 2)) AS [Average mark] 
	FROM Student GROUP BY [name], [subject] WITH ROLLUP;

-- Su dung WITH CUBE thay cho WITH ROLLUP
SELECT 
	CASE when GROUPING([name]) = 1 THEN 'All students' ELSE [name] END AS [Student name],
	CASE when GROUPING([subject]) = 1 THEN 'All subjects' ELSE [subject] END AS [Subject name], 
	CAST(AVG([mark]) AS DECIMAL(9, 2)) AS [Average mark] 
	FROM Student GROUP BY [name], [subject] WITH CUBE;

-- Dao nguoc trat tu cua [name] va [subject]
SELECT [subject] as [Subject name], [name] as [Student name], AVG([mark]) 
     FROM Student GROUP BY [subject], [name] WITH ROLLUP;